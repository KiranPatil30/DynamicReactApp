import React from 'react'

const Settlements = () => {
  return (
    <div>Settlements</div>
  )
}

export default Settlements