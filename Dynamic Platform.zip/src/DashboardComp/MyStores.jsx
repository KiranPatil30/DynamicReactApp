import React from 'react'

const MyStores = () => {
  return (
    <div>MyStores</div>
  )
}

export default MyStores